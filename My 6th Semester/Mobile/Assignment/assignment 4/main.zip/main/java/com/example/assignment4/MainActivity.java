package com.example.assignment4;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView outputTextView;
    private ProgressBar progressBar;
    private Button startButton;
    private Button pauseButton;
    private Button resumeButton;
    private Button stopButton;

    private WorkerThread workerThread;
    private Handler uiHandler;

    private static final int MAX_PROGRESS = 10;

    private static final int STATE_NEW = 0;
    private static final int STATE_RUNNABLE = 1;
    private static final int STATE_BLOCKED = 2;
    private static final int STATE_WAITING = 3;
    private static final int STATE_TIMED_WAITING = 4;
    private static final int STATE_TERMINATED = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        outputTextView = findViewById(R.id.outputTextView);
        progressBar = findViewById(R.id.progressBar);
        startButton = findViewById(R.id.startButton);
        pauseButton = findViewById(R.id.pauseButton);
        resumeButton = findViewById(R.id.resumeButton);
        stopButton = findViewById(R.id.stopButton);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWorkerThread();
            }
        });

        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseWorkerThread();
            }
        });

        resumeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resumeWorkerThread();
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopWorkerThread();
            }
        });

        uiHandler = new Handler(Looper.getMainLooper());
    }

    private void startWorkerThread() {
        outputTextView.setText("");
        progressBar.setProgress(0);
        updateThreadState(STATE_NEW);
        startButton.setEnabled(false);
        pauseButton.setEnabled(true);
        resumeButton.setEnabled(false);
        stopButton.setEnabled(true);

        workerThread = new WorkerThread();
        workerThread.start();
    }

    private void pauseWorkerThread() {
        if (workerThread != null) {
            workerThread.pauseThread();
            pauseButton.setEnabled(false);
            resumeButton.setEnabled(true);
        }
    }

    private void resumeWorkerThread() {
        if (workerThread != null) {
            workerThread.resumeThread();
            pauseButton.setEnabled(true);
            resumeButton.setEnabled(false);
        }
    }

    private void stopWorkerThread() {
        if (workerThread != null) {
            workerThread.stopThread();
            workerThread = null;
        }

        updateThreadState(STATE_TERMINATED);
        startButton.setEnabled(true);
        pauseButton.setEnabled(false);
        resumeButton.setEnabled(false);
        stopButton.setEnabled(false);
    }

    private void updateThreadState(final int state) {
        uiHandler.post(new Runnable() {
            @Override
            public void run() {
                outputTextView.setText(getStateString(state));
            }
        });
    }

    private String getStateString(int state) {
        switch (state) {
            case STATE_NEW:
                return "Thread State: NEW";
            case STATE_RUNNABLE:
                return "Thread State: RUNNABLE";
            case STATE_BLOCKED:
                return "Thread State: BLOCKED";
            case STATE_WAITING:
                return "Thread State: WAITING";
            case STATE_TIMED_WAITING:
                return "Thread State: TIMED_WAITING";
            case STATE_TERMINATED:
                return "Thread State: TERMINATED";
            default:
                return "Unknown Thread State";
        }
    }
    private class WorkerThread extends Thread {
        private boolean isStopped;
        private boolean isPaused;

        @Override
        public void run() {
            updateThreadState(STATE_RUNNABLE);

            for (int i = 1; i <= MAX_PROGRESS; i++) {
                if (isStopped) {
                    break;
                }

                final int count = i;
                updateOutputText("Count: " + count);

                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setProgress(count);
                    }
                });

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            if (!isStopped) {
                updateThreadState(STATE_TERMINATED);

                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        updateOutputText("Thread completed");
                    }
                });
            }
        }

        private synchronized void pauseThread() {
            isPaused = true;
            updateThreadState(STATE_WAITING);
        }

        private synchronized void resumeThread() {
            isPaused = false;
            updateThreadState(STATE_RUNNABLE);
            notify();
        }

        private void stopThread() {
            isStopped = true;
            interrupt();
        }

        private void updateOutputText(final String message) {
            uiHandler.post(new Runnable() {
                @Override
                public void run() {
                    outputTextView.append(message + "\n");
                }
            });
        }

        @Override
        public void interrupt() {
            isStopped = true;
            super.interrupt();
        }
    }
}

