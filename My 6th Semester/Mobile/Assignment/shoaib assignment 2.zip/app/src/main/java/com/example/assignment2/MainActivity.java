package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    BroadcastReceiver broadcastReceiver;

    Intent intentDialogueScreen;

    Intent intentFullScreen;

    static TextView txtPrint;

    public static void addLog(String paramString) {
        TextView textView = txtPrint;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(txtPrint.getText().toString());
        stringBuilder.append("\n");
        stringBuilder.append(paramString);
        textView.setText(stringBuilder.toString());
    }

    public void onBtnDialogue(View ParamView)
    { startActivity(intentDialogueScreen); }

    public void onBtnFull(View ParamView)
    { startActivity(intentFullScreen); }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPrint = (TextView)findViewById(R.id.txtPrint);
        txtPrint.setMovementMethod(new ScrollingMovementMethod());
        intentDialogueScreen = new Intent(getApplicationContext(), DialogueActivity.class);
        intentFullScreen = new Intent(getApplicationContext(), FullActivity.class);
        broadcastReceiver = new BroadcastReceiver() {

            public void onReceive(Context param1Context, Intent param1Intent)
            { MainActivity.addLog(param1Intent.getStringExtra("sLine")); }
        };
        IntentFilter intentFilter = new IntentFilter("logMessage");
        registerReceiver(broadcastReceiver, intentFilter);
        addLog("MainActivity.onCreate() ...");

    }

    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
        addLog("MainActivity.onDestroy() ...");
    }

    protected void onPause() {
        super.onPause();
        addLog("MainActivity.onPause() ...");
    }

    protected void onRestart() {
        super.onRestart();
        addLog("MainActivity.onRestart( ...");
    }

    protected void onResume() {
        super.onResume();
        addLog("MainActivity.onResume() ...");
    }

    protected void onStart() {
        super.onStart();
        addLog("MainActivity.onStart() ...");
    }

    protected void onStop() {
        super.onStop();
        addLog("MainActivity.onStop() ...");
    }



}






