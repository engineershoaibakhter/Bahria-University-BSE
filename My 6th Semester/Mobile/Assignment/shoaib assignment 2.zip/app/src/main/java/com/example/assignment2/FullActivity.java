package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class FullActivity extends AppCompatActivity {

    public void addLog(String paramString) {
        Intent intent = new Intent();
        intent.setAction("logMessage");
        intent.putExtra("sLine", paramString);
        sendBroadcast(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full);

        setTitle("Full Screen Activity");
        addLog("FullActivity.onCreate() ...");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        addLog("FullActivity.onDestroy() ...");
    }

    @Override
    protected void onPause() {
        super.onPause();
        addLog("FullActivity.onPause() ...");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        addLog("FullActivity.onRestart() ...");
    }

    @Override
    protected void onResume() {
        super.onResume();
        addLog("FullActivity.onResume() ...");
    }

    @Override
    protected void onStart() {
        super.onStart();
        addLog("FullActivity.onStart() ...");
    }

    @Override
    protected void onStop() {
        super.onStop();
        addLog("FullActivity.onStop() ...");
    }
}
